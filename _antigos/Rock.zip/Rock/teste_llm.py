import logging

logging.basicConfig(level=logging.INFO)  # antes dos imports do projeto

import asyncio

from tratamentos import llm


async def main():
    print(await llm.responder("Qual a capital da França?"))


asyncio.run(main())
