import logging

logging.basicConfig(level=logging.INFO)  # antes dos imports do projeto

import asyncio

from tratamentos.evolution import enviar_mensagem


async def main():
    # troque pelo número de OUTRO aparelho
    ok = await enviar_mensagem("5511XXXXXXXXX@s.whatsapp.net", "teste do bot")
    logging.info("enviado: %s", ok)


asyncio.run(main())
